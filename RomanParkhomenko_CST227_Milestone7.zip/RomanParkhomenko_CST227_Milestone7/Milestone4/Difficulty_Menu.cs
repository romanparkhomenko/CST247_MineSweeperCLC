﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 * Roman Parkhomenko CST227 10/05/2018
 * This program extends Milestone 5 of the Minesweeper Application.
 * In this program, we added a PlayerStats class to manage high score data.
 * We also added a HighScoreForm that displays the data from the PlayerStats Class.
 * The data in PlayerStats is kept in a highscore.csv file for reusability. Upon
 * beating high scores, the data will be manipulated to reflect winners. Upon winning or losing,
 * the .CSV prints the current high scores to the form. Upon winning, the user can submit
 * their initials and time to the .CSV
 * 
 * All work is my own.
*/

namespace Milestone4 {
    public partial class Difficulty_Menu : Form {

        public Difficulty_Menu() {
            InitializeComponent();
            this.CenterToScreen();
        }

        // When play game btn is clicked
        private void play_Click(object sender, EventArgs e) {
            if (easy_btn.Checked) {
                // create new form and pass difficulty
                Grid game = new Grid(1);
                // show game form
                game.Show();
            } else if (moderate_btn.Checked) {
                // create new from and pass difficulty
                Grid game = new Grid(2);
                // show game form
                game.Show();
            } else if (difficult_btn.Checked) {
                // create new from and pass difficulty
                Grid game = new Grid(3);
                // show game form
                game.Show();
            }
        }
    }
}