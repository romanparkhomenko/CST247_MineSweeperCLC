﻿namespace Milestone4 {
    partial class HighScoreForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HighScoreForm));
            this.label1 = new System.Windows.Forms.Label();
            this.highscore_btn = new System.Windows.Forms.Button();
            this.initials_textbox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.highscore_label = new System.Windows.Forms.Label();
            this.yourScore_label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Minesweeper High Scores";
            // 
            // highscore_btn
            // 
            this.highscore_btn.Location = new System.Drawing.Point(181, 309);
            this.highscore_btn.Name = "highscore_btn";
            this.highscore_btn.Size = new System.Drawing.Size(91, 34);
            this.highscore_btn.TabIndex = 3;
            this.highscore_btn.Text = "Submit";
            this.highscore_btn.UseVisualStyleBackColor = true;
            this.highscore_btn.Click += new System.EventHandler(this.highscore_btn_Click);
            // 
            // initials_textbox
            // 
            this.initials_textbox.Location = new System.Drawing.Point(12, 318);
            this.initials_textbox.Name = "initials_textbox";
            this.initials_textbox.Size = new System.Drawing.Size(89, 20);
            this.initials_textbox.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Location = new System.Drawing.Point(14, 304);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(258, 2);
            this.label3.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 289);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Enter Your Initials";
            // 
            // highscore_label
            // 
            this.highscore_label.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.highscore_label.Location = new System.Drawing.Point(9, 40);
            this.highscore_label.Name = "highscore_label";
            this.highscore_label.Size = new System.Drawing.Size(263, 242);
            this.highscore_label.TabIndex = 9;
            this.highscore_label.Text = "label6";
            this.highscore_label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // yourScore_label
            // 
            this.yourScore_label.Location = new System.Drawing.Point(118, 289);
            this.yourScore_label.Name = "yourScore_label";
            this.yourScore_label.Size = new System.Drawing.Size(80, 15);
            this.yourScore_label.TabIndex = 8;
            this.yourScore_label.Text = "Your Score:";
            // 
            // HighScoreForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 353);
            this.Controls.Add(this.highscore_label);
            this.Controls.Add(this.yourScore_label);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.initials_textbox);
            this.Controls.Add(this.highscore_btn);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "HighScoreForm";
            this.Text = "High Score Form";
            this.Load += new System.EventHandler(this.HighScoreForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button highscore_btn;
        private System.Windows.Forms.TextBox initials_textbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label highscore_label;
        private System.Windows.Forms.Label yourScore_label;
    }
}