﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * Roman Parkhomenko CST227 10/05/2018
 * This program extends Milestone 5 of the Minesweeper Application.
 * In this program, we added a PlayerStats class to manage high score data.
 * We also added a HighScoreForm that displays the data from the PlayerStats Class.
 * The data in PlayerStats is kept in a highscore.csv file for reusability. Upon
 * beating high scores, the data will be manipulated to reflect winners. Upon winning or losing,
 * the .CSV prints the current high scores to the form. Upon winning, the user can submit
 * their initials and time to the .CSV
 * 
 * All work is my own.
*/

namespace Milestone4 {
    // PlayerStat Class extending system IComparable interface.
    public class PlayerStats : IComparable<PlayerStats> {
        
        // Getters and Setters for PlayerStat Details.
        public string initials { get; set; }
        public string level { get; set; }
        public TimeSpan time { get; set; }

        // Declare Constructor.
        public PlayerStats(string initials, string level, TimeSpan time) {
            this.initials = initials;
            this.level = level;
            this.time = time;
        }

        //Compare method to check competetitor scores.
        public int CompareTo(PlayerStats other) {
            return time.CompareTo(other.time);
        }
    }
}