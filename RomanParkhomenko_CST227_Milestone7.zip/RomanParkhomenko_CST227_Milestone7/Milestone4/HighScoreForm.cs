﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/*
 * Roman Parkhomenko CST227 10/05/2018
 * This program extends Milestone 5 of the Minesweeper Application.
 * In this program, we added a PlayerStats class to manage high score data.
 * We also added a HighScoreForm that displays the data from the PlayerStats Class.
 * The data in PlayerStats is kept in a highscore.csv file for reusability. Upon
 * beating high scores, the data will be manipulated to reflect winners. Upon winning or losing,
 * the .CSV prints the current high scores to the form. Upon winning, the user can submit
 * their initials and time to the .CSV
 * 
 * All work is my own.
*/

namespace Milestone4 {
    public partial class HighScoreForm : Form {
        // Declare variables for difficulty, score, and win status. 
        public string difficulty; 
        public TimeSpan score;
        public bool win;

        // Create List for PlayerStats on each difficulty.
        public List<PlayerStats> easy = new List<PlayerStats>();
        public List<PlayerStats> medium = new List<PlayerStats>();
        public List<PlayerStats> hard = new List<PlayerStats>();

        public HighScoreForm(int difficulty, TimeSpan score, bool win) {

            // Read loop for CSV File.
            foreach (string line in File.ReadLines("highscore.csv")) {

                // Split line into substring array.
                var values = line.Split(',');

                // Dependent on difficulty value, add user to Stats List.
                if (values[1] == "easy") {
                    easy.Add(new PlayerStats(values[0], values[1], TimeSpan.Parse(values[2])));
                } else if (values[1] == "medium") {
                    medium.Add(new PlayerStats(values[0], values[1], TimeSpan.Parse(values[2])));
                } else if (values[1] == "hard") {
                    hard.Add(new PlayerStats(values[0], values[1], TimeSpan.Parse(values[2])));
                }

            }

            if (difficulty == 1) {
                this.difficulty = "easy";
            } else if (difficulty == 2) {
                this.difficulty = "medium";
            } else if (difficulty == 3) {
                this.difficulty = "hard";
            }

            this.score = score;
            this.win = win;
            InitializeComponent();
        }

        private void HighScoreForm_Load(object sender, EventArgs e) {

            // Hide score submission UI Elements on loss
            if (!win) {
                initials_textbox.Visible = false;
                highscore_btn.Visible = false;
                label4.Visible = false;
                yourScore_label.Visible = false;
            } else {
                initials_textbox.Visible = true;
                highscore_btn.Visible = true;
                label4.Visible = true;
                yourScore_label.Visible = true;
                yourScore_label.Text = String.Format("{0:00}:{1:00}:{2:00}.{3:00}", score.Hours, score.Minutes, score.Seconds, score.Milliseconds / 10);
            }

            // Print top 5 winners for each difficulty.
            string output = "Difficulty:    " + difficulty + Environment.NewLine + Environment.NewLine;

            if (difficulty == "easy") {
                foreach (var stat in easy) {
                    output += stat.initials + ":        " + stat.time + Environment.NewLine + Environment.NewLine;
                }
            } else if (difficulty == "medium") {
                foreach (var stat in medium) {
                    output += stat.initials + ":        " + stat.time + Environment.NewLine + Environment.NewLine;
                }
            } else if (difficulty == "hard") {
                foreach (var stat in hard) {
                    output += stat.initials + ":        " + stat.time + Environment.NewLine + Environment.NewLine;
                }

            }

            // Print everything in uppercase for legibility.
            highscore_label.Text = output.ToUpper();
            this.CenterToScreen();
        }


        // Submit Initials and highscore.
        private void highscore_btn_Click(object sender, EventArgs e) {

            //Conditionals to check difficulty level of where to add score.
            // Upon selecting difficulty, loop through top 5 scores to print correctly.
            if (difficulty == "easy") {
                easy[5] = new PlayerStats(initials_textbox.Text, difficulty, score);
                var newList = easy.OrderByDescending(PlayerStats => PlayerStats.time).ToList();
                for (var i = 0; i >= 4; i++) {
                    easy[i] = newList[i];
                }
            } else if (difficulty == "medium") {
                medium[5] = new PlayerStats(initials_textbox.Text, difficulty, score);
                var newList = medium.OrderByDescending(PlayerStats => PlayerStats.time).ToList();
                for (var i = 0; i >= 4; i++) {
                    medium[i] = newList[i];
                }
            } else if (difficulty == "hard") {
                hard[5] = new PlayerStats(initials_textbox.Text, difficulty, score);
                var newList = hard.OrderByDescending(PlayerStats => PlayerStats.time).ToList();
                for (var i = 0; i >= 4; i++) {
                    hard[i] = newList[i];
                }
            }

            // Check if file already exists, if not, create one.
            if (!File.Exists("highscore.csv")) {
                File.Create("highscore.csv").Close();
            }
            string delimter = ",";
            List<string[]> output = new List<string[]>();

            // Loop to add data to CSV based on difficulty.
            for (var i = 0; i < 5; i++) {
                output.Add(new string[] { easy[i].initials, easy[i].level, Convert.ToString(easy[i].time) });
            }
            for (var i = 0; i < 5; i++) {
                output.Add(new string[] { medium[i].initials, medium[i].level, Convert.ToString(medium[i].time) });
            }
            for (var i = 0; i < 5; i++) {
                output.Add(new string[] { hard[i].initials, hard[i].level, Convert.ToString(hard[i].time) });
            }

            int length = output.Count;

            // Use TextWriter to write data to file.
            using (System.IO.TextWriter writer = File.CreateText("highscore.csv")) {
                for (int index = 0; index < length; index++) {

                    writer.WriteLine(string.Join(delimter, output[index]));

                }
            }

            // Print and format winners.
            string newScore = "Difficulty: " + difficulty + Environment.NewLine + Environment.NewLine;

            if (difficulty == "easy") {
                foreach (var stat in easy) {
                    newScore += stat.initials + ": " + stat.time + Environment.NewLine + Environment.NewLine;
                }
            } else if (difficulty == "medium") {
                foreach (var stat in medium) {
                    newScore += stat.initials + ": " + stat.time + Environment.NewLine + Environment.NewLine;
                }
            } else if (difficulty == "hard") {
                foreach (var stat in hard) {
                    newScore += stat.initials + ": " + stat.time + Environment.NewLine + Environment.NewLine;
                }

            }

            highscore_label.Text = newScore.ToUpper();
            initials_textbox.Visible = false;
            highscore_btn.Visible = false;
            label4.Visible = false;
            yourScore_label.Visible = false;

        }

    }
}