﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

/*
 * Roman Parkhomenko CST227 10/05/2018
 * This program extends Milestone 5 of the Minesweeper Application.
 * In this program, we added a PlayerStats class to manage high score data.
 * We also added a HighScoreForm that displays the data from the PlayerStats Class.
 * The data in PlayerStats is kept in a highscore.csv file for reusability. Upon
 * beating high scores, the data will be manipulated to reflect winners. Upon winning or losing,
 * the .CSV prints the current high scores to the form. Upon winning, the user can submit
 * their initials and time to the .CSV
 * 
 * All work is my own.
*/

namespace Milestone4 {
    public partial class Grid : Form {
        public ClickCell[,] square;
        int size;

        // Create Stopwatch object from the Diagnostics Library
        public Stopwatch stopWatch = new Stopwatch();

        // Get difficulty from Menu
        public int difficulty;

        public Grid(int difficulty) {
            InitializeComponent();
            // Set difficulty
            this.difficulty = difficulty;
        }

        private void Form_Game_Load(object sender, EventArgs e) {
            // start timer
            stopWatch.Start();

            // AutoSize form to fit different game grids
            this.AutoSize = true;
            this.AutoSizeMode = AutoSizeMode.GrowAndShrink;

            // use difficulty to set size of game Grid
            size = difficulty * 10;

            // create array of ClickCells
            square = new ClickCell[size, size];

            // loop through to create game Grid
            for (int i = 0; i < size; i++) {
                for (int j = 0; j < size; j++) {
                    // create new clickable Cell button
                    square[i, j] = new ClickCell();
                    int x = j * 25;
                    int y = i * 25;
                    square[i, j].Location = new System.Drawing.Point(x, y);
                    square[i, j].Size = new System.Drawing.Size(25, 25);
                    square[i, j].setRow(i);
                    square[i, j].setColumn(j);
                    square[i, j].createGrid(this);
                    this.Controls.Add(square[i, j]);
                }
            }

            // Number of Cells
            double cellNumber = size * size;

            // Generate random percentage for live numbers
            Random rnd = new Random();
            double ranPercent = rnd.Next(15, 20);
            ranPercent = ranPercent / 100;
            double randomCount = Math.Round(cellNumber * ranPercent, 0);

            int[] randomLive = new int[Convert.ToInt32(randomCount)];

            // Create array for random live cells
            for (int i = 0; i < randomCount; i++) {
                double cellLive = rnd.Next(0, Convert.ToInt32(cellNumber));

                int pos = Array.IndexOf(randomLive, cellLive);
                if (pos > -1) {
                    return;
                } else {
                    randomLive[i] = Convert.ToInt32(cellLive);
                }
            }

            // Loop through to create live cells
            int liveCounter = 0;
            for (int i = 0; i < square.GetLength(0); i++) {
                for (int j = 0; j < square.GetLength(0); j++) {
                    if (randomLive.Contains(liveCounter)) {
                        square[i, j].setLive(true);
                    }
                    liveCounter++;
                }
            }

            // Loop to set neighbor count.
            int neighborsCounter = 0;
            for (int i = 0; i < square.GetLength(0); i++) {
                for (int j = 0; j < square.GetLength(0); j++) {
                    neighborsCounter = 0;
                    bool cellVal = square[i, j].getLive();
                    if (cellVal == false) {
                        // check left neighbor cell
                        if (i > 0) {
                            bool val = square[i - 1, j].getLive();
                            if (val) {
                                neighborsCounter++;
                            }
                        }

                        // check right neighbor cell
                        if (i < square.GetLength(0) - 1) {
                            bool val = square[i + 1, j].getLive();
                            if (val) {
                                neighborsCounter++;
                            }
                        }

                        // check top neighbor cell
                        if (j > 0) {
                            bool val = square[i, j - 1].getLive();
                            if (val) {
                                neighborsCounter++;
                            }
                        }

                        // check bottom neighbor cell
                        if (j < square.GetLength(0) - 1) {
                            bool val = square[i, j + 1].getLive();
                            if (val) {
                                neighborsCounter++;
                            }
                        }

                        // check top left neighbor cell
                        if ((i > 0) && (j > 0)) {
                            bool val = square[i - 1, j - 1].getLive();
                            if (val) {
                                neighborsCounter++;
                            }
                        }

                        // check top right neighbor cell
                        if ((i < square.GetLength(0) - 1) && (j > 0)) {
                            bool val = square[i + 1, j - 1].getLive();
                            if (val) {
                                neighborsCounter++;
                            }
                        }

                        // check bottom left neighbor cell
                        if ((i > 0) && (j < square.GetLength(0) - 1)) {
                            bool val = square[i - 1, j + 1].getLive();
                            if (val) {
                                neighborsCounter++;
                            }
                        }

                        // check bottom right neighbor cell
                        if ((i < square.GetLength(0) - 1) && (j < square.GetLength(0) - 1)) {
                            bool val = square[i + 1, j + 1].getLive();
                            if (val) {
                                neighborsCounter++;
                            }
                        }
                        // setNeighbors
                        square[i, j].setNeighbors(neighborsCounter);
                    } else {
                        // if live setNeighbors to 9 
                        square[i, j].setNeighbors(9);
                    }
                }
            }
            this.CenterToScreen();
        }

        // function to print grid
        public virtual void print() {

            for (int i = 0; i < square.GetLength(0); i++) {
                int counter = 0;
                for (int j = 0; j < square.GetLength(0); j++) {
                    if (counter < square.GetLength(0)) {
                        bool val = square[i, j].getLive();
                        if (val) {
                            square[i, j].revealLive();
                        } else {
                            square[i, j].revealNeighbors();
                        }

                    }
                }
            }
        }

        // Recursive algorithm to reveal cells with no neighbors
        public void revealZeros(int i, int j) {

            bool cellVal = square[i, j].getLive();
            if (cellVal == false) {
                // leftNeighbor
                if (i > 0) {
                    // Get Neighbors
                    double val = square[i - 1, j].getNeighbors();
                    bool visited = square[i - 1, j].getVisited();

                    // if neighbor 0
                    if ((Convert.ToInt32(val) == 0) && (!visited)) {
                        // turn neighbor to visited
                        square[i - 1, j].setVisited(true);
                        square[i - 1, j].revealNeighbors();
                        revealZeros(i - 1, j);
                    } else if ((Convert.ToInt32(val) < 9) && (!visited)) {
                        square[i - 1, j].setVisited(true);
                        square[i - 1, j].revealNeighbors();
                    }
                }

                // rightNeighbor
                if (i < square.GetLength(0) - 1) {
                    // Get Neighbors
                    double val = square[i + 1, j].getNeighbors();
                    bool visited = square[i + 1, j].getVisited();

                    // if neighbor 0
                    if ((Convert.ToInt32(val) == 0) && (!visited)) {
                        // turn neighbor to visited
                        square[i + 1, j].setVisited(true);
                        square[i + 1, j].revealNeighbors();
                        revealZeros(i + 1, j);
                    } else if ((Convert.ToInt32(val) < 9) && (!visited)) {
                        square[i + 1, j].setVisited(true);
                        square[i + 1, j].revealNeighbors();
                    }
                }

                // topNeighbor
                if (j > 0) {
                    // Get Neighbors
                    double val = square[i, j - 1].getNeighbors();
                    bool visited = square[i, j - 1].getVisited();

                    // if neighbor 0
                    if ((Convert.ToInt32(val) == 0) && (!visited)) {
                        // turn neighbor to visited
                        square[i, j - 1].setVisited(true);
                        square[i, j - 1].revealNeighbors();
                        revealZeros(i, j - 1);
                    } else if ((Convert.ToInt32(val) < 9) && (!visited)) {
                        square[i, j - 1].setVisited(true);
                        square[i, j - 1].revealNeighbors();
                    }
                }

                // bottomNeighbor
                if (j < square.GetLength(0) - 1) {
                    double val = square[i, j + 1].getNeighbors();
                    bool visited = square[i, j + 1].getVisited();

                    // if neighbor 0
                    if ((Convert.ToInt32(val) == 0) && (!visited)) {
                        // turn neighbor to visited
                        square[i, j + 1].setVisited(true);
                        square[i, j + 1].revealNeighbors();
                        revealZeros(i, j + 1);
                    } else if ((Convert.ToInt32(val) < 9) && (!visited)) {
                        square[i, j + 1].setVisited(true);
                        square[i, j + 1].revealNeighbors();
                    }
                }
            }
            return;
        }

        // function to check if game is won.
        public void checkWin() {
            int cellsVisited = 0;
            int visitedcounter = size * size;

            for (int i = 0; i < size; i++) {
                for (int j = 0; j < size; j++) {
                    // Check all cells is they have been visited
                    if (square[i, j].getVisited()) {
                        cellsVisited++;
                    }
                    // Check all cells if they are a mine
                    if (square[i, j].getLive()) {
                        cellsVisited++;
                    }
                }
            }
            // If statement to check win condition
            if (cellsVisited == visitedcounter) {
                // Stop Timer and get TimeSpan object.
                stopWatch.Stop();
                TimeSpan ts = stopWatch.Elapsed;

                // Format and display the TimeSpan value.
                string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}", ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10);
                string text = "I don't know how you did it, but YOU WON!" + Environment.NewLine + "Time elapsed: " + elapsedTime + "seconds.";

                // Show Dialog Box on Win.
                DialogResult result = MessageBox.Show(text, "", MessageBoxButtons.OK);
                if (result == DialogResult.OK) {
                    bool win = true;
                    HighScoreForm highScore = new HighScoreForm(difficulty, ts, win);
                    highScore.Show();
                } else if (result == DialogResult.Cancel) {
                    bool win = true;
                    HighScoreForm highScore = new HighScoreForm(difficulty, ts, win); ;
                    highScore.Show();
                }
            }
        }

    }
}