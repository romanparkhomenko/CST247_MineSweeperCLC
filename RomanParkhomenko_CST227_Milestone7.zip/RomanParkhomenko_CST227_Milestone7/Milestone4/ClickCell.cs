﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

/*
 * Roman Parkhomenko CST227 10/05/2018
 * This program extends Milestone 5 of the Minesweeper Application.
 * In this program, we added a PlayerStats class to manage high score data.
 * We also added a HighScoreForm that displays the data from the PlayerStats Class.
 * The data in PlayerStats is kept in a highscore.csv file for reusability. Upon
 * beating high scores, the data will be manipulated to reflect winners. Upon winning or losing,
 * the .CSV prints the current high scores to the form. Upon winning, the user can submit
 * their initials and time to the .CSV
 * 
 * All work is my own.
*/

namespace Milestone4 {
    // Extend button Class
    public class ClickCell : Button {

        //declare variables for cell
        private double row;
        private double column;
        private bool visited;
        private bool live;
        private double neighbors; 

        // Set initial count to 0
        public int count = 0;

        // Click Cell constructor
        public ClickCell() {
            this.BackColor = Color.LightBlue;
            this.Text = "";
            this.setRow(-1);
            this.setColumn(-1);
            this.setVisited(false);
            this.setLive(false);
            this.setNeighbors(0);
        }

        // Getters and Setters
        public int getCount() {
            return this.count;
        }

        public void setCount() {
            this.count = this.count + 1;
        }

        public void setRow(double row) {
            this.row = row;
        }

        public void setColumn(double column) {
            this.column = column;
        }

        public void setVisited(bool visited) {
            this.visited = visited;
        }

        public void setLive(bool live) {
            this.live = live;
        }

        public void setNeighbors(double neighbors) {
            this.neighbors = neighbors;
        }

        public double getRow() {
            return this.row;
        }

        public double getColumn() {
            return this.column;
        }

        public bool getVisited() {
            return this.visited;
        }

        public bool getLive() {
            return this.live;
        }

        public double getNeighbors() {
            return this.neighbors;
        }

        protected override void OnClick(EventArgs e) {

        }

        public Grid Grid;

        public void createGrid(Grid form) {
            Grid = form;
        }

        public void PrintGrid(Grid form) {
            form.print();
        }

        public void winGrid(Grid form) {
            form.checkWin();
        }

        public void revealZerosGrid(Grid form) {
            form.revealZeros(Convert.ToInt32(this.getRow()), Convert.ToInt32(this.getColumn()));
        }

        // Switch structure for mouse button click
        protected override void OnMouseDown(MouseEventArgs e) {
            switch (MouseButtons) {
                // Clicking Left Mouse Button:
                case MouseButtons.Left:

                    // If you hit a bomb, bring up highscore menu.
                    if (this.getNeighbors() == 9) {
                        PrintGrid(Grid);
                        string text = "Game Over";
                        DialogResult result = MessageBox.Show(text, "", MessageBoxButtons.OK);
                        if (result == DialogResult.OK) {
                            Grid.stopWatch.Stop();
                            TimeSpan ts = Grid.stopWatch.Elapsed;
                            bool win = false;
                            HighScoreForm highScore = new HighScoreForm(Grid.difficulty, ts, win);
                            highScore.Show();
                        } else if (result == DialogResult.Cancel) {
                            Grid.stopWatch.Stop();
                            TimeSpan ts = Grid.stopWatch.Elapsed;
                            bool win = false;
                            HighScoreForm highScore = new HighScoreForm(Grid.difficulty, ts, win); ;
                            highScore.Show();
                        }
                    } else if (this.getNeighbors() == 0) {
                        // if you hit an 0
                        this.BackColor = Color.LightGray;
                        this.Image = null;
                        revealZerosGrid(Grid);
                    }
                      // if you hit anything else
                      else if (this.getNeighbors() > 0) {
                        this.BackColor = Color.LightGray;
                        this.Image = null;
                        this.Text = Convert.ToString(this.getNeighbors());
                    }
                    this.setVisited(true);
                    winGrid(Grid);
                    break;

                // On Right Mouse Click
                case MouseButtons.Right:
                    // change text
                    this.Text = "";
                    // Assign an image to the button.
                    this.BackColor = Color.LightGray;
                    this.Image = Properties.Resources.flag;
                    this.BackgroundImageLayout = ImageLayout.Stretch;
                    break;
            }
        }

        // reveal the bomb in cell is live
        public void revealLive() {
            // change text
            this.Text = "";
            // Assign an image to the button.
            this.BackColor = Color.LightGray;
            this.Image = Properties.Resources.bomb;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        // reveal the Neighbors for each cell
        public void revealNeighbors() {
            // if button has neighbors
            if (this.getNeighbors() > 0) {
                this.Text = Convert.ToString(this.getNeighbors());
            } else {
                this.Text = "";
            }
            // Assign an image to the button.
            this.BackColor = Color.LightGray;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

    }

}