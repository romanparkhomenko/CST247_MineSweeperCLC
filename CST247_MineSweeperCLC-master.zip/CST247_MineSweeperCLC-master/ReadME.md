GCU CST-247 CLC Minesweeper Project
